const PKEY="pole_playlists", EKEY="pole_custom_exercises", FKEY="pole_figures";
let type="exercise", editId=null, running=false, timer=null, remaining=0, launch=null, pos=0;
const read=(k,d=[])=>{try{return JSON.parse(localStorage.getItem(k)||JSON.stringify(d))||d}catch{return d}};
const save=(k,v)=>localStorage.setItem(k,JSON.stringify(v));
const esc=s=>String(s??"").replaceAll("&","&amp;").replaceAll("<","&lt;").replaceAll(">","&gt;").replaceAll('"',"&quot;").replaceAll("'","&#039;");

function defaultExercises(){
  const p=typeof PROGRAMS!=="undefined"?PROGRAMS:(typeof programs!=="undefined"?programs:null);
  if(!p)return [];
  return p.flatMap(x=>(x.sections||[]).flatMap(s=>(s[1]||[]).map((e,i)=>({
    id:"default_"+x.id+"_"+s[0]+"_"+e[0],name:e[0],duration:e[1],seconds:Number(e[4])||60,
    description:e[3]||"",muscles:"",program:x.id,custom:false
  }))));
}
function customExercises(){return read(EKEY).map(e=>({id:e.id,name:e.name,duration:e.duration?e.duration+" s":"",seconds:Number(e.duration)||60,description:e.description||"",muscles:e.muscles||"",image:e.image||"",custom:true}))}
function exercises(){return [...defaultExercises(),...customExercises()]}
function figures(){return read(FKEY).map(f=>({id:f.id,name:f.name,level:f.level||"",image:f.image||"",mastered:!!f.mastered,favorite:!!f.favorite,type:"figure"}))}
function items(){return type==="exercise"?exercises():figures()}
function image(e){if(e.image)return e.image;if(!e.custom&&type==="exercise"){let i=defaultExercises().findIndex(x=>x.id===e.id);if(i>=0)return "assets/exercises/"+String(i+1).padStart(2,"0")+".jpg"}return ""}
function meta(e){return e.type==="figure"?e.level+(e.mastered?" · ✓ Maîtrisée":" · À travailler")+(e.favorite?" · ★":""):(e.duration||"")+(e.muscles?" · "+e.muscles:"")}
function setType(t){type=t;tabEx.classList.toggle("active",t==="exercise");tabFig.classList.toggle("active",t==="figure");closeEdit();renderPicker();renderPlaylists()}
function renderPicker(selected=[]){const a=items();picker.innerHTML=a.length?a.map(e=>`<label class="pick"><input type="checkbox" value="${esc(e.id)}" ${selected.includes(e.id)?"checked":""}><span class="thumb">${image(e)?`<img src="${image(e)}">`:"Photo à ajouter"}</span><span><span class="name">${esc(e.name)}</span><span class="meta">${esc(meta(e))}</span></span></label>`).join(""):'<div class="empty">Aucun élément disponible.</div>'}
function checked(id){return [...document.querySelectorAll("#"+id+" input:checked")].map(x=>x.value)}
function createPlaylist(){const n=name.value.trim(),ids=checked("picker");if(!n)return alert("Donne un nom.");if(!ids.length)return alert("Sélectionne au moins un élément.");save(PKEY,[...read(PKEY),{id:"pl_"+Date.now(),type,name:n,description:description.value.trim(),items:ids}]);name.value="";description.value="";renderPicker();renderPlaylists()}
function plItems(p){const a=items();return p.items.map(id=>a.find(x=>x.id===id)).filter(Boolean)}
function renderPlaylists(){const ps=read(PKEY).filter(p=>p.type===type);playlists.innerHTML=ps.length?ps.map(p=>{const a=plItems(p);return `<div class="playlist"><h3 style="margin:0">${esc(p.name)}</h3><div class="sub">${a.length} élément${a.length>1?"s":""}${p.description?" · "+esc(p.description):""}</div><div>${a.map((e,i)=>`<div class="item"><span class="meta">${i+1}</span><span><span class="name">${esc(e.name)}</span><span class="meta">${esc(meta(e))}</span></span></div>`).join("")}</div><div class="actions"><button class="small" onclick="launchPlaylist('${p.id}')">▶ Lancer</button><button class="small" onclick="editPlaylist('${p.id}')">Modifier</button><button class="small danger" onclick="deletePlaylist('${p.id}')">Supprimer</button></div></div>`}).join(""):'<div class="empty">Aucune playlist pour le moment.</div>'}
function editPlaylist(id){const p=read(PKEY).find(x=>x.id===id);if(!p)return;editId=id;editor.classList.remove("hidden");editName.value=p.name;editDescription.value=p.description||"";const a=items();editPicker.innerHTML=a.map(e=>`<label class="pick"><input type="checkbox" value="${esc(e.id)}" ${p.items.includes(e.id)?"checked":""}><span class="thumb">${image(e)?`<img src="${image(e)}">`:"Photo à ajouter"}</span><span><span class="name">${esc(e.name)}</span><span class="meta">${esc(meta(e))}</span></span></label>`).join("");scrollTo({top:editor.offsetTop-20,behavior:"smooth"})}
function saveEdit(){const p=read(PKEY).find(x=>x.id===editId),ids=checked("editPicker");if(!p||!ids.length)return alert("Sélectionne au moins un élément.");p.name=editName.value.trim()||p.name;p.description=editDescription.value.trim();p.items=ids;save(PKEY,read(PKEY));closeEdit();renderPicker();renderPlaylists()}
function closeEdit(){editId=null;editor.classList.add("hidden")}
function deletePlaylist(id){if(!confirm("Supprimer cette playlist ?"))return;save(PKEY,read(PKEY).filter(p=>p.id!==id));renderPlaylists()}
function launchPlaylist(id){const p=read(PKEY).find(x=>x.id===id);if(!p)return;const a=plItems(p);if(!a.length)return alert("Cette playlist ne contient plus d'éléments disponibles.");launch={...p,items:a};pos=0;document.getElementById("launch").classList.add("show");loadLaunch()}
function closeLaunch(){clearInterval(timer);timer=null;running=false;document.getElementById("launch").classList.remove("show")}
function loadLaunch(){clearInterval(timer);timer=null;running=false;const e=launch.items[pos],src=e.type==="figure"?e.image:image(e);count.textContent=(pos+1)+" / "+launch.items.length;visual.innerHTML=src?`<img src="${src}" alt="">`:'<div class="placeholder">Photo à ajouter</div>';launchTitle.textContent=e.name;launchMeta.textContent=e.type==="figure"?meta(e):((e.duration||"")+(e.muscles?" · "+e.muscles:""));remaining=e.type==="figure"?0:(e.seconds||60);updateLaunch()}
function updateLaunch(){const e=launch.items[pos];timer.textContent=e.type==="figure"?"":fmt(remaining);mainBtn.textContent=running?"Pause":(e.type==="figure"?"Figure affichée":"Démarrer");note.textContent=e.description||""}
function fmt(s){return String(Math.floor(s/60)).padStart(2,"0")+":"+String(Math.max(0,s%60)).padStart(2,"0")}
function toggleTimer(){const e=launch.items[pos];if(e.type==="figure")return;if(running){clearInterval(timer);timer=null;running=false;updateLaunch();return}running=true;timer=setInterval(()=>{remaining--;updateLaunch();if(remaining<=0){clearInterval(timer);timer=null;running=false;navigator.vibrate?.([180,80,180]);setTimeout(nextItem,350)}},1000);updateLaunch()}
function nextItem(){clearInterval(timer);timer=null;running=false;if(pos<launch.items.length-1){pos++;loadLaunch()}else{launchTitle.textContent="Playlist terminée ✦";launchMeta.textContent="Bravo !";timer.textContent="✓";mainBtn.textContent="Terminé";note.textContent="Tu peux quitter la playlist."}}
function prevItem(){if(pos>0){pos--;loadLaunch()}}
renderPicker();renderPlaylists();